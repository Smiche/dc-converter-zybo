/*
 * converter.h
 *
 *  Created on: Dec 12, 2022
 *      Author: dHoundenko & samppa
 */

#ifndef SRC_CONVERTER_H_
#define SRC_CONVERTER_H_



#endif /* SRC_CONVERTER_H_ */

extern float model(float PID_out);
