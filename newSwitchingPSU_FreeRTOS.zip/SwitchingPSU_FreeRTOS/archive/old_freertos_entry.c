/*
 Copyright (C) 2017 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
 Copyright (C) 2012 - 2018 Xilinx, Inc. All Rights Reserved.

 Permission is hereby granted, free of charge, to any person obtaining a copy of
 this software and associated documentation files (the "Software"), to deal in
 the Software without restriction, including without limitation the rights to
 use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 the Software, and to permit persons to whom the Software is furnished to do so,
 subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software. If you wish to use our Amazon
 FreeRTOS name, please do so in a fair use way that does not cause confusion.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 http://www.FreeRTOS.org
 http://aws.amazon.com/freertos


 1 tab == 4 spaces!
 */

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
/* Xilinx includes. */
#include "xil_types.h"
#include "xil_printf.h"
#include "xil_io.h"
#include "xttcps.h"
#include "xparameters.h"
#include "xscugic.h"
#include "xuartps_hw.h"
/* Sample commands from FreeRTOS-CLI*/
#include "Sample-CLI-commands.h"

#include <zynq_registers.h> // Defines hardware registers

/*** Global Variables ***/
#define TIMER_ID	1
#define DELAY_10_SECONDS	10000UL
#define DELAY_1_SECOND		1000UL
#define TIMER_CHECK_THRESHOLD	9
#define mainUART_COMMAND_CONSOLE_STACK_SIZE	( configMINIMAL_STACK_SIZE * 3UL )
#define mainUART_COMMAND_CONSOLE_TASK_PRIORITY	( tskIDLE_PRIORITY )

/* The Tx and Rx tasks as described at the top of this file. */
static void prvTxTask(void *pvParameters);
static void prvRxTask(void *pvParameters);
static void pwdTest(void *pvParameters);
/*
 * The task that manages the FreeRTOS+CLI input and output.
 */
extern void vUARTCommandConsoleStart(uint16_t usStackSize,
		UBaseType_t uxPriority);

static void vTimerCallback(TimerHandle_t pxTimer);
/*-----------------------------------------------------------*/
XScuGic xFreeRTOSInterruptController;
/* The queue used by the Tx and Rx tasks, as described at the top of this
 file. */
static TaskHandle_t xTxTask;
static TaskHandle_t xRxTask;
static TaskHandle_t pwdTask;

static QueueHandle_t xQueue = NULL;
static TimerHandle_t xTimer = NULL;
char HWstring[15] = "Hello World";
long RxtaskCntr = 0;

void init() {
	/**
	 * Register commands from FreeRTOS-CLI.
	 */
	vRegisterSampleCLICommands();
	/**
	 * Begin listening for UART commands.
	 */
	vUARTCommandConsoleStart( mainUART_COMMAND_CONSOLE_STACK_SIZE,
	mainUART_COMMAND_CONSOLE_TASK_PRIORITY);

	/**
	 * Switch to INPUT mode
	 */
	Xil_Out32((AXI_SW_TRI_ADDRESS), 0x5);
	/**
	 * LED to OUTPUT mode
	 */
	Xil_Out32((AXI_LED_TRI_ADDRESS), 0x0);

}

int main(void) {
	xil_printf("Hello from Freertos example main\r\n");

	const TickType_t x10seconds = pdMS_TO_TICKS(DELAY_10_SECONDS);

	/* Create the two tasks.  The Tx task is given a lower priority than the
	 Rx task, so the Rx task will leave the Blocked state and pre-empt the Tx
	 task as soon as the Tx task places an item in the queue. */
	xTaskCreate(prvTxTask, /* The function that implements the task. */
	(const char *) "Tx", /* Text name for the task, provided to assist debugging only. */
	configMINIMAL_STACK_SIZE, /* The stack allocated to the task. */
	NULL, /* The task parameter is not used, so set to NULL. */
	tskIDLE_PRIORITY, /* The task runs at the idle priority. */
	&xTxTask);

	xTaskCreate(prvRxTask, (const char *) "GB",
	configMINIMAL_STACK_SIZE,
	NULL,
	tskIDLE_PRIORITY + 1, &xRxTask);

	xTaskCreate(pwdTest, (const char *) "PWD",
	configMINIMAL_STACK_SIZE,
	NULL,
	tskIDLE_PRIORITY + 1, &pwdTask);

	/* Create the queue used by the tasks.  The Rx task has a higher priority
	 than the Tx task, so will preempt the Tx task and remove values from the
	 queue as soon as the Tx task writes to the queue - therefore the queue can
	 never have more than one item in it. */
	xQueue = xQueueCreate(1, /* There is only one space in the queue. */
	sizeof( HWstring )); /* Each space in the queue is large enough to hold a uint32_t. */

	/* Check the queue was created. */
	configASSERT(xQueue);

	/* Create a timer with a timer expiry of 10 seconds. The timer would expire
	 after 10 seconds and the timer call back would get called. In the timer call back
	 checks are done to ensure that the tasks have been running properly till then.
	 The tasks are deleted in the timer call back and a message is printed to convey that
	 the example has run successfully.
	 The timer expiry is set to 10 seconds and the timer set to not auto reload. */
	xTimer = xTimerCreate((const char *) "Timer", x10seconds,
	pdFALSE, (void *) TIMER_ID, vTimerCallback);
	/* Check the timer was created. */
	configASSERT(xTimer);

	/* start the timer with a block time of 0 ticks. This means as soon
	 as the schedule starts the timer will start running and will expire after
	 10 seconds */
	xTimerStart(xTimer, 0);

	/* Start the tasks and timer running. */
	vTaskStartScheduler();

	/* If all is well, the scheduler will now be running, and the following line
	 will never be reached.  If the following line does execute, then there was
	 insufficient FreeRTOS heap memory available for the idle and/or timer tasks
	 to be created.  See the memory management section on the FreeRTOS web site
	 for more details. */
	for (;;)
		;
}

/*-----------------------------------------------------------*/
static void prvTxTask(void *pvParameters) {
	const TickType_t x1second = pdMS_TO_TICKS(DELAY_1_SECOND);

	for (;;) {
		/* Delay for 1 second. */
		vTaskDelay(x1second);
//		/* Send the next value on the queue.  The queue should always be
//		 empty at this point so a block time of 0 is used. */
//		xQueueSend(xQueue, /* The queue being written to. */
//		HWstring, /* The address of the data being sent. */
//		0UL); /* The block time. */
	}
}

/*-----------------------------------------------------------*/
static void prvRxTask(void *pvParameters) {
	for (;;) {
		RxtaskCntr++;
	}
}

/*-----------------------------------------------------------*/
static void pwdTest(void *pvParameters) {
	const TickType_t x1second = pdMS_TO_TICKS(DELAY_1_SECOND);

	float pwd = 0.01;
	float cur = pwd;
	while (1) {
		vTaskDelay(x1second);

		u8 read = Xil_In8((AXI_SW_DATA_ADDRESS));
		xil_printf("Button: %d", read);

		cur += pwd;
		unsigned char mask = 1;
		if (cur >= 1) {
			Xil_Out8((AXI_LED_DATA_ADDRESS), read & ~mask | 1);
			cur = pwd;
		} else {
			Xil_Out8((AXI_LED_DATA_ADDRESS), read & ~mask | 0);
		}
	}
}

/*-----------------------------------------------------------*/
static void vTimerCallback(TimerHandle_t pxTimer) {
	long lTimerId;
	configASSERT(pxTimer);

	lTimerId = (long) pvTimerGetTimerID(pxTimer);

	if (lTimerId != TIMER_ID) {
		xil_printf("FreeRTOS Hello World Example FAILED");
	}

	/* If the RxtaskCntr is updated every time the Rx task is called. The
	 Rx task is called every time the Tx task sends a message. The Tx task
	 sends a message every 1 second.
	 The timer expires after 10 seconds. We expect the RxtaskCntr to at least
	 have a value of 9 (TIMER_CHECK_THRESHOLD) when the timer expires. */
	if (RxtaskCntr >= TIMER_CHECK_THRESHOLD) {
		xil_printf("FreeRTOS Hello World Example PASSED");
	} else {
		xil_printf("FreeRTOS Hello World Example FAILED");
	}

	vTaskDelete(xRxTask);
	vTaskDelete(xTxTask);
}
